# SocialMarket - Buy & Sell Social Media Accounts - Windows App

This is a Visual Studio project that wraps the website [https://digitalskeleton.com.ng](https://digitalskeleton.com.ng) as a native Windows app.

## How to Build

1. Open Visual Studio 2022
2. Select "Open a project or solution"
3. Select the `.sln` file in this folder
4. Right-click the project and select "Set as StartUp Project"
5. Select your target platform (x64, x86, ARM64)
6. Click "Build" > "Build Solution" or press Ctrl+Shift+B
7. Click "Debug" > "Start Without Debugging" or press Ctrl+F5

## Features

- WebView2-based app that loads the website
- Full Windows integration
- Native Windows look and feel
- Internet connectivity support
- Multi-platform support (x64, x86, ARM64)

## Customization

- Modify `MainPage.xaml.cs` to add custom functionality
- Update `Package.appxmanifest` to change app metadata
- Replace app icons in the Assets folder
- Modify XAML files for UI customization

## Requirements

- Visual Studio 2022 with UWP development workload
- Windows 10 version 1903 (build 18362) or higher
- Windows App SDK
- Internet connection for loading web content

## Deployment

- For development: Run directly from Visual Studio
- For distribution: Create an MSIX package through Visual Studio
- For Microsoft Store: Use the generated MSIX package

## Website

Original website: https://digitalskeleton.com.ng
Generated on: 2025-07-30 19:43:40
