using Microsoft.UI.Xaml.Controls;

namespace SocialMarketBuySellSocialMediaAccounts
{
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
            LoadWebsite();
        }

        private async void LoadWebsite()
        {
            await webView.EnsureCoreWebView2Async();
            webView.Source = new System.Uri("https://digitalskeleton.com.ng");
        }
    }
}